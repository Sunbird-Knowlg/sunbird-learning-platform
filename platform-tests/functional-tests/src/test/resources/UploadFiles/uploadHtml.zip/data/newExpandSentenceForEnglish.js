var words = [
{
		"questionId" :"1",
		"sentenceId" : 1,
		"words" :
		[{
			"wordStr": "I went",
			"wordType": 1,		
			"queId": 0,
			"position": 2
		},
		{
			"wordStr": "Where?",
			"wordType": 2,		
			"queId": 1,
			"position": 0
		},
		{
			"wordStr": "to Mumbai",
			"wordType": 3,		
			"queId": 1,
			"position": 3
		},
		{
			"wordStr": "to a jungle",
			"wordType": 3,		
			"queId": 1,
			"position": 3
		},
		{
			"wordStr": "in the air",
			"wordType": 3,		
			"queId": 1,
			"position": 3
		},
		{
			"wordStr": "How?",
			"wordType": 2,		
			"queId": 2,
			"position": 0
		},
		{
			 "wordStr": "on foot",
			"wordType": 3,		
			"queId": 2,
			"position": 4
		},
		{
			 "wordStr": "flying",
			"wordType": 3,		
			"queId": 2,
			"position": 4
		},
		{
			 "wordStr": "quickly",
			"wordType": 3,		
			"queId": 2,
			"position": 4
		},
		{
			 "wordStr": "When?",
			"wordType": 2,		
			"queId": 3,
			"position": 0
		},
		{
			 "wordStr": "in the morning",
			"wordType": 3,		
			"queId": 3,
			"position": 1
		},
		{
			 "wordStr": "at night ",
			"wordType": 4,		
			"queId": 3,
			"position": 1
		},
		{
			 "wordStr": "last year",
			"wordType": 4,		
			"queId": 3,
			"position": 1
		},
		{
			 "wordStr": "For what?",
			"wordType": 4,		
			"queId": 4,
			"position": 0
		},
		{
			 "wordStr": " to fight",
			"wordType": 4,		
			"queId": 4,
			"position": 5
		},
		{
			 "wordStr": " for work",
			"wordType": 4,		
			"queId": 4,
			"position": 5
		},
		{
			 "wordStr": " to dance",
			"wordType": 4,		
			"queId": 4,
			"position": 5
		}
		]
	},
	{
		"questionId" :"2",
		"sentenceId" : 2,
		"words" :
		[{
			"wordStr": "I like",
			"wordType": 1,		
			"queId": 0,
			"position": 1
		},
		{
			 "wordStr": "What?",
			"wordType": 2,		
			"queId": 1,
			"position": 0
		},
		{
			 "wordStr": "to dance",
			"wordType": 3,		
			"queId": 1,
			"position": 2
		},
		{
			 "wordStr": "to fight",
			"wordType": 3,		
			"queId": 1,
			"position": 2
		},
		{
			 "wordStr": "to joke",
			"wordType": 3,		
			"queId": 1,
			"position": 2
		},
		{
			 "wordStr": "Where?",
			"wordType": 2,		
			"queId": 2,
			"position": 0
		},
		{
			 "wordStr": "in the rain",
			"wordType": 3,		
			"queId": 2,
			"position": 4
		},
		{
			 "wordStr": "in school",
			"wordType": 3,		
			"queId": 2,
			"position": 4
		},
		{
			 "wordStr": "in the car",
			"wordType": 3,		
			"queId": 2,
			"position": 4
		},
		{
			 "wordStr": "How?",
			"wordType": 2,		
			"queId": 3,
			"position": 0
		},
		{
			 "wordStr": "quickly",
			"wordType": 3,		
			"queId": 3,
			"position": 3
		},
		{
			 "wordStr": "happily",
			"wordType": 3,		
			"queId": 3,
			"position": 3
		},
		{
			 "wordStr": "angrily",
			"wordType": 3,		
			"queId": 3,
			"position": 3
		}
		]
	},
	{
		"questionId" :"3",
		"sentenceId" : 3,
		"words" :
		[{
			"wordStr": "I got",
			"wordType": 1,		
			"queId": 0,
			"position": 1
		},
		{
			"wordStr": "What?",
			"wordType": 2,		
			"queId": 1,
			"position": 0
		},
		{
			"wordStr": "books",
			"wordType": 3,		
			"queId": 1,
			"position": 3
		},
		{
			"wordStr": "trees",
			"wordType": 3,		
			"queId": 1,
			"position": 3
		},
		{
			"wordStr": "sweets",
			"wordType": 3,		
			"queId": 1,
			"position": 3
		},
		{
			"wordStr": "How many?",
			"wordType": 2,		
			"queId": 2,
			"position": 0
		},
		{
			"wordStr": "many",
			"wordType": 3,		
			"queId": 2,
			"position": 2
		},
		{
			"wordStr": "a few",
			"wordType": 3,		
			"queId": 2,
			"position": 2
		},
		{
			"wordStr": "some",
			"wordType": 3,		
			"queId": 2,
			"position": 2
		},
		{
			"wordStr": "Where?",
			"wordType": 2,		
			"queId": 3,
			"position": 0
		},
		{
			"wordStr": "on Mars",
			"wordType": 3,		
			"queId": 3,
			"position": 4
		},
		{
			"wordStr": "in school",
			"wordType": 3,		
			"queId": 3,
			"position": 4
		},
		{
			"wordStr": "in America",
			"wordType": 3,		
			"queId": 3,
			"position": 4
		}
		]
	},
	{
		"questionId" :"4",
		"sentenceId" : 4,
		"words" :
		[{
			"wordStr": "I sing",
			"wordType": 1,		
			"queId": 0,
			"position": 2
		},
		{
			"wordStr": "How?",
			"wordType": 2,		
			"queId": 1,
			"position": 0
		},
		{
			"wordStr": "quickly",
			"wordType": 3,		
			"queId": 1,
			"position": 3
		},
		{
			"wordStr": "happily",
			"wordType": 3,		
			"queId": 1,
			"position": 3
		},
		{
			"wordStr": "loudly",
			"wordType": 3,		
			"queId": 1,
			"position": 3
		},
		{
			"wordStr": "Where?",
			"wordType": 2,		
			"queId": 2,
			"position": 0
		},
		{
			"wordStr": "in the river",
			"wordType": 3,		
			"queId": 2,
			"position": 4
		},
		{
			"wordStr": "in my bed",
			"wordType": 3,		
			"queId": 2,
			"position": 4
		},
		{
			"wordStr": "on the road",
			"wordType": 3,		
			"queId": 2,
			"position": 4
		},
		{
			"wordStr": "When?",
			"wordType": 2,		
			"queId": 3,
			"position": 0
		},
		{
			"wordStr": "everyday",
			"wordType": 3,		
			"queId": 3,
			"position": 1
		},
		{
			"wordStr": "on Monday",
			"wordType": 3,		
			"queId": 3,
			"position": 1
		},
		{
			"wordStr": "on my birthday",
			"wordType": 3,		
			"queId": 3,
			"position": 1
		}
		]
	},
	{
		"questionId" :"5",
		"sentenceId" : 5,
		"words" :
		[{
			"wordStr": "I fell",
			"wordType": 1,		
			"queId": 0,
			"position": 1
		},
		{
			"wordStr": "How?",
			"wordType": 2,		
			"queId": 1,
			"position": 0
		},
		{
			"wordStr": "angrily",
			"wordType": 3,		
			"queId": 1,
			"position": 2
		},
		{
			"wordStr": "suddenly",
			"wordType": 3,		
			"queId": 1,
			"position": 2
		},
		{
			"wordStr": "slowly",
			"wordType": 3,		
			"queId": 1,
			"position": 2
		},
		{
			"wordStr": "Where?",
			"wordType": 2,		
			"queId": 2,
			"position": 0
		},
		{
			"wordStr": "in the pond",
			"wordType": 3,		
			"queId": 2,
			"position": 3
		},
		{
			"wordStr": "in the park",
			"wordType": 3,		
			"queId": 2,
			"position": 3
		},
		{
			"wordStr": "on the road",
			"wordType": 3,		
			"queId": 2,
			"position": 3
		},
		{
			"wordStr": "With whom?",
			"wordType": 2,		
			"queId": 3,
			"position": 0
		},
		{
			"wordStr": "with my dog",
			"wordType": 3,		
			"queId": 3,
			"position": 4
		},
		{
			"wordStr": "with my friend",
			"wordType": 3,		
			"queId": 3,
			"position": 4
		},
		{
			"wordStr": "with my sister ",
			"wordType": 3,		
			"queId": 3,
			"position": 4
		}
		]
	},
	{
		"questionId" :"6",
		"sentenceId" : 6,
		"words" :
		[{
			"wordStr": "I do not like",
			"wordType": 1,		
			"queId": 0,
			"position": 1
		},
		{
			"wordStr": "What?",
			"wordType": 2,		
			"queId": 1,
			"position": 0
		},
		{
			"wordStr": "to jump",
			"wordType": 3,		
			"queId": 1,
			"position": 2
		},
		{
			"wordStr": "to sleep",
			"wordType": 3,		
			"queId": 1,
			"position": 2
		},
		{
			"wordStr": "to cook",
			"wordType": 3,		
			"queId": 1,
			"position": 2
		},
		{
			"wordStr": "Where?",
			"wordType": 2,		
			"queId": 2,
			"position": 0
		},
		{
			"wordStr": "on the moon",
			"wordType": 3,		
			"queId": 2,
			"position": 3
		},
		{
			"wordStr": "in Antarctica",
			"wordType": 3,		
			"queId": 2,
			"position": 3
		},
		{
			"wordStr": "in the bathroom",
			"wordType": 3,		
			"queId": 2,
			"position": 3
		},
		{
			"wordStr": "When?",
			"wordType": 2,		
			"queId": 4,
			"position": 0
		},
		{
			"wordStr": "in the evening",
			"wordType": 3,		
			"queId": 4,
			"position": 4
		},
		{
			"wordStr": "everyday",
			"wordType": 3,		
			"queId": 4,
			"position": 4
		},
		{
			"wordStr": "at night",
			"wordType": 3,		
			"queId": 4,
			"position": 4
		}
		]
	}
	
]