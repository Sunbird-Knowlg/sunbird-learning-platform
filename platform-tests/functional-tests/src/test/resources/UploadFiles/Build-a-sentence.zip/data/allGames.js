var gameData = [
{
	"sentBuildTitleE" : "Build - a - sentence",
	"sentBuildSubtitleE" : "Grammar Rules",
	"playE" : "Play",
	"nextE" : "Next",
	"startE" : "Start",
	"gameOverE" : "Game Over",
	"restartE" : "Restart",
	
}];