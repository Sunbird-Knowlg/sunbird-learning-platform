require 'net/http'

module SamzaJobs
	class YARN
		def initialize(url)
			@uri = URI.parse(url)
		end
		def get_job_list(env="")
			res = Net::HTTP.get_response(@uri)
			if res.code != "200"
				raise "Unable to get job list"
			else
				parse_jobs(res.body,env)
			end
		end
		def parse_jobs(json_data,env)
			begin
				result = JSON.parse(json_data)
				jobs =  result["apps"]["app"]
				if(env.empty?)
					return jobs
				else
					return jobs.select {|j| j["name"].start_with?(env) }
				end
			rescue  Exception => e
				return []
			end
		end
	end
end