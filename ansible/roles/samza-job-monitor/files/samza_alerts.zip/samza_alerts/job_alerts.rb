#!/usr/bin/ruby

require 'json'
require 'net/http'
require 'logger'

require_relative 'yarn'
require_relative 'slack'

JOBS_COUNT 	= (ENV['JOBS_COUNT'] || "5").to_i
URL 		= ENV['YARN_URL'] || "http://localhost:8088/ws/v1/cluster/apps?states=RUNNING"
SAMZA_ENV	= ENV['SAMZA_ENV'] || "qa"
MONITORINGING_ENV_NAME = ENV['MONITORINGING_ENV_NAME'] || "qa"
SLACK_CHANNEL = ENV['SLACK_CHANNEL'] || "testing"
SLACK_URL 	= ENV['SLACK_URL'] || "https://hooks.slack.com/services/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"
CHECK_DELAY	= (ENV['CHECK_DELAY'] || "30").to_i
LOG_FILE	= (ENV['LOG_FILE'] || "/var/log/samza-monitor/samza-monitor.log")

module SamzaJobs
  class Alert

    def initialize
      @yarn= SamzaJobs::YARN.new(URL)
      @alert=SamzaJobs::SlackAlert.new(SLACK_URL, SLACK_CHANNEL)
      @sent=false
      @log = Logger.new(LOG_FILE, 'daily')
      @log.level = Logger::INFO
    end

    def check_jobs
      @log.info("JOB STARTED")
      while(true)
        @log.debug("TAKING NAP FOR #{CHECK_DELAY}s")
        sleep CHECK_DELAY
        @log.info("JUST WOKE UP! VERIFYING IF ALL JOBS ARE RUNNING")
        begin
          jobs = @yarn.get_job_list(SAMZA_ENV)
          @log.debug("GOT LIST OF JOBS FROM YARN #{jobs}")
          validate_jobs(jobs)
        rescue Exception => e
          puts e
          @log.error("UNKNOWN ERROR, #{e}")
        end
      end
      @log.info("JOB FINISHED")
    end

    def validate_jobs(jobs)
      if (JOBS_COUNT != jobs.size)
        @log.info("DO SOMETHING SOON!! ALL JOBS ARE NOT RUNNING")
        @alert.send_alert(JOBS_COUNT, jobs, MONITORINGING_ENV_NAME) unless @sent
        @sent=true
      else
        @log.info("RELAX, ALL JOBS ARE RUNNING")
        @alert.send_success(MONITORINGING_ENV_NAME) if @sent
        @sent=false
      end
    end
  end
end

alert = SamzaJobs::Alert.new
alert.check_jobs
