require 'slack-notifier'

module SamzaJobs
	class SlackAlert
		def initialize(url, slack_channel)
			@notifier = Slack::Notifier.new url, channel: slack_channel, username: 'samzaAlerts'
		end
		def send_alert(expected_count,jobs,env)
			message = [{
				fallback: "Jobs counts are not matching. expected #{expected_count} and actual is #{jobs.size}",
				title: "Jobs counts are not matching in #{env.upcase}",
				pretext:  "Expected #{expected_count} and actual is #{jobs.size}",
				color: "danger"
			}]

			jobs.each do |j|
				m={
					title: "The job #{j["name"]} is running",
					color: "warning"
				}
				message << m
			end

	     	# puts "Availble jobs are #{jobs_names(jobs)}"
	     	@notifier.ping "Jobs counts are not matching", attachments: message
	    end

	    def send_success(env)
	    	message = [{
				title: "Jobs are back to normal in #{env.upcase}",
				color: "good"
			}]
			@notifier.ping "Jobs are back to normal in #{env.upcase}", attachments: message
	    end
	end
end
